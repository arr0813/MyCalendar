//
//  RootViewController.m
//  Demo
//
//  Created by Zontonec on 16/11/11.
//  Copyright © 2016年 Zontonec. All rights reserved.
//

#import "RootViewController.h"
#import "CalendarView.h"

#define SCREENWIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREENHEIGHT [[UIScreen mainScreen] bounds].size.height

@interface RootViewController ()
@property (nonatomic , strong) CalendarView  * CalendarView;
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [button setTitle:@"下月" forState:UIControlStateNormal];
    
    [button setFrame:CGRectMake(100, 100, [[UIScreen mainScreen] bounds].size.width - 200 , 50)];
    
    [button setBackgroundColor:[UIColor redColor]];
    
    [button addTarget:self action:@selector(calendarButtonDidPress) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button];
    
    self.CalendarView = [[CalendarView alloc]initWithFrame:CGRectMake(0, 150, SCREENWIDTH, 500) colorArr:@[[UIColor whiteColor],[UIColor cyanColor],[UIColor greenColor],[UIColor redColor]] clickDateBlock:^(NSString *Date) {
        
        //传过来的值做的事情;
        NSLog(@"%@",Date);
        
    }];

    [self.view addSubview:self.CalendarView];
}

-(void)calendarButtonDidPress{
    
    NSLog(@"按钮被点击了");
    [self.CalendarView reloadCalendarViewWithDate:@"2017-04-12" textOrBackGround:3];
    
}
//-(void)receiveBlock{
//    
//    NSLog(@"这是接收Block的函数");
//    
//    [CaledarView SendDateWithSelectedDate:nil date:^(NSString *Date) {
//        
//        NSLog(@"%@",Date);
//        
//    }];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
