//
//  CalendarView.h
//  Demo
//
//  Created by Zontonec on 17/1/11.
//  Copyright © 2017年 Zontonec. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 
 介绍：
 <1>initWithFrame为初始化方法，clickDateBlock里面返回的为点击的日期，点击某个日期完成什么操作写在这；
 <2>reloadCalendarViewWithDate为重载日历的方法，传进来一个日期，显示全月的日历，日期格式为：2016-01-01；上月、下月的点击事件可以通过此方法来实现
 <3>reloadCalendarViewWithArr为重载方法1，如果只有一种背景色要设置可以用这个方法
    参数：arr里面保存的是需要设置背景色的日期，dateColor为日期的颜色
    arr数组里面数据的格式为：@[@{date="2016-01-01"},@{date="2016-01-01"}]
    即arr数组里面的每一个元素都是一个字典，字典中保存了一个key=date、value=“XXXX-XX-XX”的键值对
 <4>reloadCalendarViewWithDataDictArr为重载方法2，比如请假设置为红色、出勤设置为绿色、缺勤设置为青色时用这个方法
    参数：DictArr为保存数据的数组，textOrBack=1字体改变颜色，textOrBack=2边框改变颜色，textOrBack=3背景改变颜色
    DictArr为二维数组，一维是请假、出勤、缺勤等的数据，二维中的第0个元素是保存数据的字典，第1个元素是当前类型的数据显示的背景色
    DictArr格式为 : @[
                        @[      
                            @[@{date="2016-01-01"},@{date="2016-01-01"}],
                            绿色
                         ]
                        @[
                            @[@{date="2016-01-01"},@{date="2016-01-01"}],
                            红色
                        ]
                    ]
 */

typedef void (^SendDateBlock)(NSString *Date);


@interface CalendarView : UIView

/** 传递日期的Block */
@property(nonatomic, copy) SendDateBlock sendDateBlock;

//传进来日历背景色、当天的日期背景色、选中日期背景色
-(instancetype)initWithFrame:(CGRect)frame colorArr:(NSArray *)arr clickDateBlock:(SendDateBlock)sendDateBlock ;

//重新设置日历日期-->需要传进一个日期来 需要传textOrBack
-(void)reloadCalendarViewWithDate:(NSString *)date textOrBackGround:(NSInteger )textOrBack;

//下面两个方法为重载并设置有数据的日期的方法，因为不管请求数据是否成功都需要显示某月日期，所以重新设置日期和设置背景色的方法分开

/*重载方法1
 使用情况：只需要设置一种背景色时
*/
-(void)reloadCalendarViewWithArr:(NSArray *)arr color:(UIColor *)dateColor;

/*重载方法2
 使用情况：有数据的日期为请假、出勤、缺勤等多种数据时
 数组为二维数组，一维是请假、出勤、缺勤等的数据，二维中的第0个元素是保存数据的字典，第1个元素是当前类型的数据显示的背景色
 */
-(void)reloadCalendarViewWithDataDictArr:(NSArray *)DictArr textOrBackGround:(NSInteger )textOrBack;

@end
