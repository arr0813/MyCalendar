//
//  ConvertDate.m
//  BGH
//
//  Created by Zontonec on 17/1/9.
//  Copyright © 2017年 Zontonec. All rights reserved.
//

#import "ConvertDate.h"

@implementation ConvertDate

#pragma mark - 转换为指定的日期格式:XXXX-XX-XX -
+(NSString *)ConvertDateWithYear:(NSInteger )year months:(NSInteger )months day:(NSInteger )day{
    
    NSString * monthsNum = [self ToNumberWithNum:months];
    
    NSString * daysNum = [self ToNumberWithNum:day];
    
    return [NSString stringWithFormat:@"%ld-%@-%@",year,monthsNum,daysNum];
    
}
#pragma mark - 转换为年、月、日 -
+(NSArray *)ConvertDateWithDate:(NSString *)date;{

    return [date componentsSeparatedByString:@"-"];    
}
#pragma mark - 小于10的数字转换为0X格式 -
+(NSString *)ToNumberWithNum:(NSInteger )num{
    
    return num > 9 ? [NSString stringWithFormat:@"%ld",num] : [NSString stringWithFormat:@"0%ld",num];
}
#pragma mark - NSDate --> NSString -
+(NSString *)ConvertNSDateToNSString:(NSDate *)date{
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"YYYY-MM-dd"];
    
    NSString *dateString = [dateFormatter stringFromDate:date];
    
    return dateString;
}
@end
