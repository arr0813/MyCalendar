//
//  ConvertDate.h
//  BGH
//
//  Created by Zontonec on 17/1/9.
//  Copyright © 2017年 Zontonec. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ConvertDate : NSObject

#pragma mark - NSInteger年月日转换为XXXX-XX-XX
+(NSString *)ConvertDateWithYear:(NSInteger )year months:(NSInteger )months day:(NSInteger )day;

#pragma mark -XXXX-XX-XX切割为年、月、日
+(NSArray *)ConvertDateWithDate:(NSString *)date;

#pragma mark - 小于10的数字转换为XX格式 -
+(NSString *)ToNumberWithNum:(NSInteger )num;

#pragma mark - NSDate -->YYYY-MM-dd-
+(NSString *)ConvertNSDateToNSString:(NSDate *)date;
@end
