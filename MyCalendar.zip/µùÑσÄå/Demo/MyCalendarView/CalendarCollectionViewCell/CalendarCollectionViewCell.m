//
//  CalendarCollectionViewCell.m
//  BGH
//
//  Created by Zontonec on 17/1/4.
//  Copyright © 2017年 Zontonec. All rights reserved.
//

#import "CalendarCollectionViewCell.h"

@implementation CalendarCollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self = [[[NSBundle mainBundle]loadNibNamed:@"CalendarCollectionViewCell" owner:self options:nil] lastObject];
        
    }
    return self ;
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
