//
//  CalendarCollectionViewCell.h
//  BGH
//
//  Created by Zontonec on 17/1/4.
//  Copyright © 2017年 Zontonec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CalendarCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *CalendarDateLabel;

@end
